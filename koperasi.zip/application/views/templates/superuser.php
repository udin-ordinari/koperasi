<li class="nav-item">
	<a class="nav-link menu-link" href="<?php echo base_url('master/anggota');?>">
		<i data-feather="user"></i>
		<span>Anggota / Nasabah</span>
	</a>
</li>
<li class="nav-item">
	<a class="nav-link menu-link" href="<?php echo base_url('master/pengguna');?>">
		<i data-feather="users"></i>
		<span>Pengguna</span>
	</a>
</li>
<li class="nav-item">
	<a class="nav-link menu-link" href="<?php echo base_url('superuser/modules');?>">
		<i data-feather="align-left"></i>
		<span>Module Menu</span>
	</a>
</li>
<li class="nav-item">
	<a class="nav-link menu-link" href="<?php echo base_url('superuser/menus');?>">
		<i data-feather="align-justify"></i>
		<span>Menu</span>
	</a>
</li>
<li class="nav-item">
	<a class="nav-link menu-link" href="<?php echo base_url('superuser/menu_level');?>">
		<i data-feather="shield"></i>
		<span>Akses Menu</span>
	</a>
</li>
<li class="nav-item">
	<a class="nav-link menu-link" href="<?php echo base_url('master/setting/database');?>">
		<i data-feather="database"></i>
		<span>Database</span>
	</a>
</li>
<div class="card"> 
	<div class="card-body">
		<div class="col-xl-12 mx-auto" style="text-align: right;">Bulan : <strong><?php echo bulan($bulan); ?> <?php echo $tahun; ?></strong></div>
		<table id="" class="table table-bordered mb-0 fs-7">
			<thead class="table-secondary text-center">
				<tr>
					<th scope="col" style="width: 5%;">NO</th>
					<th scope="col" style="width: 5%;">Tanggal</th>
					<th scope="col" style="width: 45%;">Keterangan</th>
					<th scope="col" style="width: 15%;">Debet</th>
					<th scope="col" style="width: 15%;">Kredit</th>
					<th scope="col" style="width: 15%;">Total</th>
				</tr>
				<tr class="table-info">
					<td class="text-right kandel fs-6">Jumlah : </td>
					<td class="text-right kandel fs-6">Jumlah : </td>
					<td class="text-right kandel fs-6">Jumlah : </td>
					<td class="text-right kandel fs-6">Rp. 0</td>
					<td class="text-right kandel fs-6">Rp. 0</td>
					<td class="text-right kandel fs-6">Rp. 0</td>
				</tr>
				<tr>
					<td class="text-right kandel fs-6" colspan="3">Jumlah : </td>
					<td class="text-right kandel fs-6">Rp. 0</td>
					<td class="text-right kandel fs-6">Rp. 0</td>
					<td class="text-right kandel fs-6">Rp. 0</td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>
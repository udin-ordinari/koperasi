<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-12 11:15:35 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:35 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:35 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:35 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:35 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 11:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2025-11-12 12:28:38 --> 404 Page Not Found: Lupa-password/index
ERROR - 2025-11-12 12:28:39 --> 404 Page Not Found: Lupa-password/index
ERROR - 2025-11-12 12:28:41 --> 404 Page Not Found: Daftar/index
ERROR - 2025-11-12 12:45:11 --> 404 Page Not Found: Assets/img
ERROR - 2025-11-12 12:45:12 --> 404 Page Not Found: Assets/img
ERROR - 2025-11-12 12:45:20 --> 404 Page Not Found: Assets/img
ERROR - 2025-11-12 14:07:42 --> 404 Page Not Found: Assets/img
ERROR - 2025-11-12 14:08:16 --> 404 Page Not Found: Assets/img
ERROR - 2025-11-12 14:14:33 --> 404 Page Not Found: Assets/img
ERROR - 2025-11-12 14:15:07 --> 404 Page Not Found: Assets/img
ERROR - 2025-11-12 14:44:52 --> 404 Page Not Found: Lupa-password/index
ERROR - 2025-11-12 16:49:37 --> 404 Page Not Found: Lupa-password/index
ERROR - 2025-11-12 16:56:27 --> Severity: error --> Exception: Call to undefined method CI_Lang::autentikasi() C:\xampp\htdocs\koperasi\application\views\login\forgot.php 3
ERROR - 2025-11-12 16:56:59 --> Could not find the language line "lupa_pass_title"
ERROR - 2025-11-12 16:57:01 --> Could not find the language line "lupa_pass_title"
ERROR - 2025-11-12 16:57:33 --> Severity: error --> Exception: Call to undefined method CI_Lang::autentikasi() C:\xampp\htdocs\koperasi\application\views\login\forgot.php 3
ERROR - 2025-11-12 17:03:19 --> Severity: error --> Exception: syntax error, unexpected token "if" C:\xampp\htdocs\koperasi\application\controllers\Login.php 10
ERROR - 2025-11-12 17:03:21 --> Severity: error --> Exception: syntax error, unexpected token "if" C:\xampp\htdocs\koperasi\application\controllers\Login.php 10
ERROR - 2025-11-12 17:03:22 --> Severity: error --> Exception: syntax error, unexpected token "if" C:\xampp\htdocs\koperasi\application\controllers\Login.php 10
ERROR - 2025-11-12 17:03:33 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\koperasi\application\views\login\forgot.php 3
ERROR - 2025-11-12 17:04:57 --> Could not find the language line "lupa_pass"
ERROR - 2025-11-12 17:04:58 --> Could not find the language line "lupa_pass"
ERROR - 2025-11-12 17:05:08 --> Could not find the language line "lupa_pass"
ERROR - 2025-11-12 17:05:28 --> Could not find the language line "lupa_pass"
ERROR - 2025-11-12 17:39:08 --> 404 Page Not Found: Assets/js

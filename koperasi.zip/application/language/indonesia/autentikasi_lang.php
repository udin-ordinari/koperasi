<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['lupa_pass'] 	 = 'Lupa Password ?';
$lang['lupa_pass_title'] = 'Tidak masalah !<br>Masukkan email Anda di bawah ini dan kami akan mengirimkan instruksi untuk mengatur ulang kata sandi Anda.';
$lang['lupa_pass_btn'] 	 = 'Kirim Instruksi';
$lang['login_title'] 	 = 'Login Dashboard';
$lang['login_message'] 	 = 'Gunakan Username / Email Anda Untuk Masuk.';
$lang['username']  	 = 'Username / Email';
$lang['password']  	 = 'Password';
$lang['login_page'] 	 = 'Sudah Ingat Password ?';
$lang['login_page_btn']  = 'Masuk';
$lang['register_title']  = 'Nasabah Baru ?';
$lang['register'] 	 = 'Daftar';